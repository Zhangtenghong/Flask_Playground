from flask import Flask, render_template
app=Flask(__name__)

@app.route('/play')
def play():
  return render_template('index.html')

@app.route('/play/<times>')
def playx(times,color):
  return render_template('level2.html',box_num=int(times))

@app.route('/play/<times>/<color>')
def playx(times,color):
  return render_template('level2.html',box_num=int(times),box_color=color)

#how to put the variable in the CSS?

if __name__=="__main__":
  app.run(debug=True)

